# Desktop-Assistant-AI
This is an example of Desktop Assistant made with Python. I will keep updating it. But you can also use it. and can contribute to customize it it is very simple and beginner can also configure it easily. 
